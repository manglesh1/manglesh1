import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CountUpModule } from 'ngx-countup';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from '../../shared/shared.module';
import { HomeRoutingModule } from '../home/home-routing.module';
import { AttractionsComponent } from './attractions.component';
import { AttractionDetailComponent } from './attraction-detail/attraction-detail.component';
import { ContactComponent } from './attraction-detail/contact.component';
import { PricingComponent } from '../pricing/pricing.component';



@NgModule({
  declarations: [AttractionsComponent, AttractionDetailComponent,ContactComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    SharedModule,
    NgbModule,
    SlickCarouselModule,
    CountUpModule   
  ]
})
export class AttractionsModule { }
